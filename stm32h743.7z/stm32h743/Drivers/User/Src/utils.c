#include "utils.h"

float *gray_buffer = (float *)GRAY_BUFFER_ADDR;
const char chinese_char[311*2] = "�ĺð������ϳ���ᷢչ��������������ȥ����������������Щʶ�ⶼ֪����������ս��Ӣ������˼Ǳ�һ���������ڶ�������ȷ�ǻ�ʵ�ڴ�Ҳ���ɶ��ͬ��ʹ�������Ϊ�������ֿ�ѧ�������ʲô���Լ���ûס���˴�������������ͷ�о��ܲ��������Ѿ��������˵�����ٸ�����������Ҫ����֤����Ӧ���쿪���������ſ�������ÿ����ȫ��ǰ����ʦ�绰�鵼������ȡ��ֻ֮�������������쳣·ֱ�����ɷ�������Ｔ˼�������·���������ذ���������ӳ��ضԶ����������Ŀ������ˮ�����������Ȼ�Ϲ��н������������ӽ�������������СŮ��������˾���������������Ը��򱾸ð���ϵ������īȾ��˫ɽ�α�����Ф����ţ�ƴ�������1234567890CARYSENLKUHIOXMB";

const int B_th_int = 6;
const float B_th_flt = 6.0 / 32.0;

int min_w, max_w, min_h, max_h;
int16_t *labels_buffer = (int16_t *)LABELS_BUFFER_ADDR;
int16_t equivalence[EQ_NUM]; // ���ڴ洢��ǩ�ĵ�Ч��ϵ
int label_counts[EQ_NUM] = {0};


void initialize_equivalence(int16_t *labels) {
    for (int i = 0; i < EQ_NUM; i++) {
        equivalence[i] = i;
        label_counts[i] = 0;
    }
    for (int i = 0; i < Display_Height * Display_Width; i++) {
        labels[i] = 0;
    }
}

int16_t find(int16_t x) {
    if (x < EQ_NUM) {
        if (equivalence[x] != x) {
            equivalence[x] = find(equivalence[x]);
        }
        return equivalence[x];
    } else {
        printf("error\r\n");
        return -1;
    }
}

void union_labels(int16_t x, int16_t y) {
    int16_t rootX = find(x);
    int16_t rootY = find(y);
    if (rootX != rootY) {
        equivalence[rootY] = rootX;
    }
}

void two_pass_labeling(uint8_t* image, int16_t* labels) {
    int current_label = 2;
    // ��һ��ɨ��
    for (int y = 0; y < LCD_Height; y++) {
        for (int x = 0; x < LCD_Width; x++) {
//            printf("w-%d  h-%d\r\n",x,y);
            if (image[y * LCD_Width + x] == 0) { // �������Ϊǰ��
                int16_t left_label = (x > 0) ? labels[y * LCD_Width + x - 1] : 0;
                int16_t top_label = (y > 0) ? labels[(y - 1) * LCD_Width + x] : 0;
                if (left_label == 0 && top_label == 0) {
                    labels[y * LCD_Width + x] = current_label++;
                } else if (left_label != 0 && top_label == 0) {
                    labels[y * LCD_Width + x] = left_label;
                } else if (left_label == 0 && top_label != 0) {
                    labels[y * LCD_Width + x] = top_label;
                } else {
                    labels[y * LCD_Width + x] = left_label < top_label ? left_label : top_label;
                    union_labels(top_label, left_label);
                }
            }
        }
    }
    // �ڶ���ɨ��
    for (int y = 0; y < LCD_Height; y++) {
        for (int x = 0; x < LCD_Width; x++) {
            if (labels[y * LCD_Width + x] != 0) {
                labels[y * LCD_Width + x] = find(labels[y * LCD_Width + x]);
                label_counts[labels[y * LCD_Width + x]]++;
            }
        }
    }
}
void print_labels() {
    for (int y = 0; y < LCD_Height; y++) {
        for (int x = 0; x < LCD_Width; x++) {
            printf("%d", labels_buffer[y * LCD_Width + x]);
        }
        printf("\n");
    }
}

void set_background(uint8_t* image, int16_t* labels) {
    for (int y = 0; y < LCD_Height; y++) {
        for (int x = 0; x < LCD_Width; x++) {
            if (label_counts[labels[y * LCD_Width + x]] >= AREA_T) {
                image[y * LCD_Width + x] = 1;
            }
        }
    }
}

void Obtain_text_location(uint8_t *image,const int h,const int w)
{
    int i, j;
    min_h = h;
    min_w = w;
    max_h = 0;
    max_w = 0;
    for(i = 0; i < h; i++){
        for(j = 0; j < w; j++){
            if(image[i * w + j] == 0){
                if(min_w > j)   min_w = j;
                if(min_h > i)   min_h = i;
                if(max_w < j && (max_w == 0 || j - max_w < 25)){
                    max_w = j;
                }
                if(max_h < i && (max_h == 0 || i - max_h < 25)){
                    max_h = i;
                }
            }
        }
    }
}

void Remove_background(uint8_t *image){
    initialize_equivalence(labels_buffer);                      // ��ʼ����Ч��
    two_pass_labeling(image, labels_buffer);                    // ��������ɨ��
//    print_labels();
    set_background(image, labels_buffer);                       // ���ñ�������
    Obtain_text_location(image, Display_Height, Display_Width); // ��ȡ�ı�λ��
}

void Binarize_display_pixel(uint32_t *src, uint8_t *dis, const int h,const int w)
{
    int i, j;
    uint8_t gray;
    uint32_t data;
    uint16_t pixel;
    

    for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
            data = src[(j * w + i) / 2];        // ÿ�ζ�ȡ32λ���ݣ��������أ�
            if (i % 2 == 0) {
                pixel = data & 0xFFFF;              // ��16λ
            } else {
                pixel = (data >> 16) & 0xFFFF;      // ��16λ
            }
            gray = pixel & 0x1F;                    // �ڰ�ģʽȡ���5λ
            dis[(j * w + i)] = (gray < B_th_int) ? 0 : 1;
        }
    }
}

void Linear_insertion_to_bin(uint32_t *src, uint8_t *dst, const int min_x,
                             const int max_x, const int min_y, const int max_y)
{
    int i, j, x, y, len_x, len_y, w, h;
    float scale_x, scale_y;
    float src_x, src_y, dx, dy, A11, A12, A21, A22, value;
    
    len_x = max_x - min_x;
    len_y = max_y - min_y;

    if(len_x > 25 && len_y > 25){
        if(len_x > len_y){
            scale_x = (float)(len_x) / Net_Width;
            scale_y = (float)(len_y) / Net_Height;
            w = Net_Width;
            h = Net_Height;
        }
        else{
            scale_x = (float)(len_x) / Net_Height;
            scale_y = (float)(len_y) / Net_Width;
            w = Net_Height;
            h = Net_Width;
        }
        for(j = 0; j < h; ++j){
            for(i = 0; i < w; ++i){
                src_x = i * scale_x;
                src_y = j * scale_y;
                x = (int)src_x;
                y = (int)src_y;
                dx = src_x - x;
                dy = src_y - y;

                A11 = get_pixel(src, Display_Width, min_x + x, min_y + y);
                A12 = get_pixel(src, Display_Width, min_x + x + 1, min_y + y);
                A21 = get_pixel(src, Display_Width, min_x + x, min_y + y + 1);
                A22 = get_pixel(src, Display_Width, min_x + x + 1, min_y + y + 1);
                value = (1 - dx) * (1 - dy) * A11 + dx * (1 - dy) * 
                        A12 + (1 - dx) * dy * A21 + dx * dy * A22;

                if(value > B_th_flt){
                    dst[j * w + i] = 1;
                }
                else{
                    dst[j * w + i] = 0;
                }
            }
        }
    }
    else{
        printf("�����ѡ\r\n");
    }
}

float get_pixel(uint32_t *src, const int width, const int x, const int y){
    int index;
    uint32_t data;
    uint16_t pixel;
    uint8_t gray;
    

    if(x < 0 || y < 0 || x > Display_Width - 1 || y > Display_Height - 1){
        return 0.5;
    }
    else{
        index = (y * width + x) / 2;
        data = src[index];
        if (x % 2 == 0) {
            // ��ȡ��16λ����
            pixel = data & 0xFFFF;
        } else {
            // ��ȡ��16λ����
            pixel = (data >> 16) & 0xFFFF;
        }
        gray = pixel & 0x1F;
        return ((double)gray)/32;
    }
}

void Add_text_box(uint32_t *src, const int h, const int w, const int min_x,
                  const int max_x, const int min_y, const int max_y)
{
    int i, j;
    for (j = 0; j < h; j++){
        for (i = 0; i < w; i++){
            if(i == min_x || i == max_x || j == min_y || j == max_y){
                if (i % 2 == 0){
                    src[(j * w + i) / 2] = src[(j * w + i) / 2] & 0xFFFF0000;
                }
                else{
                    src[(j * w + i) / 2] = src[(j * w + i) / 2] & 0x0000FFFF;
                }
            }
        }
    }
}

void Transpose_matrix(uint8_t *src, float *dst,const int h, const int w, const int min_x,
                      const int max_x, const int min_y, const int max_y)
{
    int i, j, len_x, len_y;
    uint8_t value;
    len_x = max_x - min_x;
    len_y = max_y - min_y;
    
    for (i = 0; i < h; i++){
        for (j = 0; j < w; j++){
            if(len_x > len_y){
                value = src[i * w + j];
            }
            else{
                value = src[(h - i - 1) + j * h];
            }
            dst[i * w + j] = (value>0 ? 1.0 : 0);
        }
    }
}
void p_c(const int* c_char){
    int i, idx;
    for (i = 0; i<10; i++){
        if(c_char[i] != 0){
			if(c_char[i]<=285){
				idx = 2*(c_char[i]-1);
				printf("%c%c", chinese_char[idx],chinese_char[idx+1]);
			}
			else{
				idx = 285 + c_char[i] - 1;
				printf("%c", chinese_char[idx]);
			}
        }

    }
	printf("\r\n");
}


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

/****************************************************************************************************/
/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 480000000 (CPU Clock)
  *            HCLK(Hz)                       = 240000000 (AXI and AHBs Clock)
  *            AHB Prescaler                  = 2
  *            D1 APB3 Prescaler              = 2 (APB3 Clock  120MHz)
  *            D2 APB1 Prescaler              = 2 (APB1 Clock  120MHz)
  *            D2 APB2 Prescaler              = 2 (APB2 Clock  120MHz)
  *            D3 APB4 Prescaler              = 2 (APB4 Clock  120MHz)
  *            HSE Frequency(Hz)              = 25000000
  *            PLL_M                          = 5
  *            PLL_N                          = 192
  *            PLL_P                          = 2
  *            PLL_Q                          = 4
  *            PLL_R                          = 2
  *            VDD(V)                         = 3.3
  *            Flash Latency(WS)              = 4
  * @param  None
  * @retval None
  */
  
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

    /** Supply configuration update enable
    */
    HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

    /** Configure the main internal regulator output voltage
    */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    __HAL_RCC_SYSCFG_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

    while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 5;
    RCC_OscInitStruct.PLL.PLLN = 160;
    RCC_OscInitStruct.PLL.PLLP = 2;
    RCC_OscInitStruct.PLL.PLLQ = 2;
    RCC_OscInitStruct.PLL.PLLR = 4;
    RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_2;
    RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
    RCC_OscInitStruct.PLL.PLLFRACN = 0;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
    RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
    {
        Error_Handler();
    }

    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_SPI5;
    PeriphClkInitStruct.Spi45ClockSelection = RCC_SPI45CLKSOURCE_D2PCLK1;	// SPI5 �ں�ʱ��120M
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
        Error_Handler();
    }  
}


//	����MPU
//
void MPU_Config(void)
{
	MPU_Region_InitTypeDef MPU_InitStruct;

	HAL_MPU_Disable();		// �Ƚ�ֹMPU

	MPU_InitStruct.Enable 					= MPU_REGION_ENABLE;
	MPU_InitStruct.BaseAddress 			= 0x24000000;
	MPU_InitStruct.Size 						= MPU_REGION_SIZE_512KB;
	MPU_InitStruct.AccessPermission	= MPU_REGION_FULL_ACCESS;
	MPU_InitStruct.IsBufferable 		= MPU_ACCESS_BUFFERABLE;
	MPU_InitStruct.IsCacheable 			= MPU_ACCESS_CACHEABLE;
	MPU_InitStruct.IsShareable 			= MPU_ACCESS_SHAREABLE;
	MPU_InitStruct.Number 					= MPU_REGION_NUMBER0;
	MPU_InitStruct.TypeExtField 		= MPU_TEX_LEVEL0;
	MPU_InitStruct.SubRegionDisable	= 0x00;
	MPU_InitStruct.DisableExec 			= MPU_INSTRUCTION_ACCESS_ENABLE;

	HAL_MPU_ConfigRegion(&MPU_InitStruct);	

	HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);	// ʹ��MPU
}


