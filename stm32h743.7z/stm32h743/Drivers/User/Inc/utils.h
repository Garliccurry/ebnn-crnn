#ifndef _UTILS_H
#define _UTILS_H
#include "stm32h7xx_hal.h"
#include "usart.h"
#include "dcmi_ov2640.h"

#define Net_Height  50
#define Net_Width   250
#define EQ_NUM      1000
#define AREA_T      900

#define GRAY_BUFFER_ADDR    0x24025800
#define GRAY_BUFFER_SIZE    Net_Height * Net_Width * 4          //to 0x24031B50

#define NET_BIN_BUFFER_ADDR 0x24031B50
#define NET_BIN_BUFFER_SIZE Net_Height * Net_Width              //to 0x24034C24

#define LABELS_BUFFER_ADDR  0x24036000
#define LABELS_BUFFER_SIZW  Display_Height * Display_Weight * 2 //to 0x2405B800

#define DIS_BIN_BUFFER_ADDR 0x2405B800
#define DIS_BIN_BUFFER_SIZW Display_Height * Display_Weight     //to 0x2406E400




extern int min_w, max_w, min_h, max_h;

void Binarize_display_pixel(uint32_t *src, uint8_t *dis, const int h,const int w);
void Remove_background(uint8_t *image);
void Linear_insertion_to_bin(uint32_t *src,  uint8_t *dst, const int min_x,
                             const int max_x, const int min_y, const int max_y);
float get_pixel(uint32_t *src, const int width, const int x, const int y);
void Add_text_box(uint32_t *src, const int h, const int w, const int min_x,
                  const int max_x, const int min_y, const int max_y);
void Transpose_matrix(uint8_t *src, float *dst,const int h, const int w, const int min_x,
                      const int max_x, const int min_y, const int max_y);
void p_c(const int* c_char);

void SystemClock_Config(void);
void MPU_Config(void);
    
#endif

