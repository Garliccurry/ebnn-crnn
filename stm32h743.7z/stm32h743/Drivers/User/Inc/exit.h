#ifndef _EXTI_H
#define _EXTI_H
#include "stm32h7xx_hal.h"
#include "delay.h"
#include "utils.h"
#include "led.h"
#include "ebnn_help.h"

extern volatile uint8_t Infer_State;

void EXTI0_Init(void);
void EXTI4_Init(void);


#endif
