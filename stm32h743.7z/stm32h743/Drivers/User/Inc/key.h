#ifndef _KEY_H
#define _KEY_H
#include "stm32h7xx_hal.h"


#define KEY0        HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_1)  //KEY0����PC1



void KEY_Init(void);




#endif

