#ifndef EBNN_HELP_H
#define EBNN_HELP_H

#include <math.h>
#include "ebnn.h"

#define TEMP1_ADDR 0x24036000
#define TEMP2_ADDR 0x24046000


void ebnn_compute(float *input, int *output);

#endif // FUN1_H_INCLUDED
